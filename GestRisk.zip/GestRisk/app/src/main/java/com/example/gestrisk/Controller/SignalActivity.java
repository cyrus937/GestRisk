package com.example.gestrisk.Controller;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.gestrisk.R;

public class SignalActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signal);
    }

    @Override
    protected void onStart() {
        super.onStart();

        System.out.println("SignalActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("SignalActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("SignalActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        System.out.println("SignalActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        System.out.println("SignalActivity::onDestroy()");
    }

    @Override
    public void onClick(View v) {

    }
}
