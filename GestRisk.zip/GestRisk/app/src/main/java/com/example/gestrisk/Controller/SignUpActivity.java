package com.example.gestrisk.Controller;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.EditText;

import com.example.gestrisk.R;

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText nom;
    private EditText prenom;
    private EditText poste;
    private AutoCompleteTextView zone;
    private EditText email;
    private EditText passWord;
    private EditText confPassWord;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();

        System.out.println("SignUpActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        System.out.println("SignUpActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        System.out.println("SignUpActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        System.out.println("SignUpActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        System.out.println("SignUpActivity::onDestroy()");
    }

    @Override
    public void onClick(View v) {

    }
}
