package com.example.gestrisk.Controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.gestrisk.R;

import static java.lang.System.out;

public class MainActivity extends AppCompatActivity {

    private Button valide;
    private Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        valide = (Button) findViewById(R.id.button3);
        signup = (Button) findViewById(R.id.button4);

        valide.setEnabled(false);
        signup.setEnabled(false);


        valide.setEnabled(true);

        valide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signalActivityIntent = new Intent(MainActivity.this, SignalActivity.class);
                startActivity(signalActivityIntent);
            }
        });

        signup.setEnabled(true);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signUpActivityIntent = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(signUpActivityIntent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        out.println("MainActivity::onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();

        out.println("MainActivity::onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();

        out.println("MainActivity::onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();

        out.println("MainActivity::onStop()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        out.println("MainActivity::onDestroy()");
    }
}
